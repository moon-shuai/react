import React, { Component } from 'react';

class Com extends Component {
  render () {
    return (
      <div className='box'>
        <header className='header'>购物车头部</header>
        <div className="content">
          购物车
        </div>
      </div>
    )
  }
}

export default Com