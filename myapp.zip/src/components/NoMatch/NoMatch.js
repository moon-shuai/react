import React, { Component } from 'react';

class Com extends Component {
  render () {
    return (
      <div className='Nomatch'>
        404页面
      </div>
    )
  }
}

export default Com