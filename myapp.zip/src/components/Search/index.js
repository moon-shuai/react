import React, { Component } from 'react';
import SearchInput from '@/components/Search/searchInput';

class Com extends Component {
  componentDidMount () {
  }
  render () {
    return (
      <div className='box'>
        <SearchInput/>
      </div>
    )
  }
}

export default Com